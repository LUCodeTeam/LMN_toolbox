function [outputModel,validity,phiAll,psiAll,xRegressor,zRegressor] = simulateParallel(obj,xRegressor,zRegressor,localModels,leafModels)
%% SIMULATEPARALLEL  Simulates the output of a local linear neuro-fuzzy model.
%
%
%       [outputModel,phi] = simulateParallel(obj,xRegressor,zRegressor)
%
%
%   simulateParallel outputs:
%       outputModel - (N x q) Matrix of model outputs
%       phi         - (N x M) Matrix of phi (validity function values)
%
%
%   simulateParallel inputs:
%       xRegressor - (N x nx) Regression matrix of the consequents (local models).
%       zRegressor - (N x nz) Regression matrix of the premises (validity functions).
%
%
%   See also hilomot, globalModel, addChildren, calculateModelOutput,
%            calculateModelOutputQuick.
%
%
%   LMNtool - Local Model Network Toolbox
%   Tobias Ebert, 24-April-2012
%   Institute of Mechanics & Automatic Control, University of Siegen, Germany
%   Copyright (c) 2012 by Prof. Dr.-Ing. Oliver Nelles
% 
% Update T.Fischer (16.July.2013)

% Number of data samples
numberOfSamples = size(xRegressor,1);

% Number of outputs
numberOfOutputs = obj.info.numberOfOutputs;

% Determine number of regressor inputs
xNumberOfInputRegressorsSum = sum(cellfun(@length,obj.xInputDelay));
zNumberOfInputRegressorsSum = sum(cellfun(@length,obj.zInputDelay));

% preallocation for function outputs
outputModel = zeros(numberOfSamples,numberOfOutputs);
validity = ones(numberOfSamples,sum(leafModels));
phiAll = ones(numberOfSamples,length(leafModels));
psiAll = ones(numberOfSamples,length(leafModels));

% save output delays to a variable (the get method in the obj is rather slow)
xOutputDelay = obj.xOutputDelay;
zOutputDelay = obj.zOutputDelay;

% get the parameters of all leaf models
%localParameter = arrayfun(@(cobj) cobj.parameter,obj.localModels(obj.leafModels),'UniformOutput',false);
localParameter = [localModels(leafModels).parameter];
if numberOfOutputs > 1
    parameter_Part = [];
    for k = 1:numberOfOutputs
        parameter_Part{k} = localParameter(:,k:numberOfOutputs:end);
    end
end

splittingPara = [localModels(2:end).splittingParameter];
kappa = [localModels(2:end).kappa];
smoothness = obj.smoothness;
parent = [0 localModels(2:end).parent];

for k = 1:numberOfSamples % Through all samples
    % if offset is last entry
    % idx = xNumberOfInputRegressorsSum + 1; % For regression matrix x
    
    % if offset is first regressor, the xOutputDelays start at index
    % xNumberOfInputRegressorsSum+2! (delayed inputs + Offset + first idx after that)
    idx = xNumberOfInputRegressorsSum + 2; % For regression matrix x
    
    % Fill matrix with output regressors
    for out = 1:numberOfOutputs % Through all outputs
        for outReg = 1:length(xOutputDelay{out}) % Through all output regressors
            kDelay = k-xOutputDelay{out}(outReg);
            if kDelay > 0
                xRegressor(k,idx) = outputModel(kDelay,out);
            end
            idx = idx + 1;
        end
    end
    
    idx = zNumberOfInputRegressorsSum + 1; % For regression matrix z
    
    % Fill matrix with output regressors
    for out = 1:numberOfOutputs % Through all outputs
        for outReg = 1:length(zOutputDelay{out}) % Through all output regressors
            kDelay = k-zOutputDelay{out}(outReg);
            if kDelay > 0
                zRegressor(k,idx) = outputModel(kDelay,out);
            end
            idx = idx + 1;
        end
    end
    
    %     % Calculate validity function values, only one row
    %     % phi1row = obj.calculateValidity(zRegressor(k,:),obj.leafModels);
    %     phi1row = calculateValiditySub(obj.localModels,zRegressor(k,:),obj.leafModels);
    %
    %     % save phi(k,:) to variable for function output
    %     phi(k,:) = phi1row;
    %
    %     % Calculate model output for sample k AND MORE THAN ONE OUTPUT!
    %     outputModel(k,:) = obj.calcYhat(xRegressor(k,:),phi1row,localParameter);
    
    
    if length(localModels)==1 % there is only one local=global model
        
        outputModel(k,:) = xRegressor(k,:) * localParameter;
        
    else % For more than one local model
        
        psi = [1 1./(1+exp( ...
            (kappa./smoothness) .* (zRegressor(k,:)*splittingPara(1:end-1,:) + splittingPara(end,:))...
            ))];
        
        phi = psi;
        for childIdx = 4:length(phi)
            % multiply with parent psi if necessary to calculate phi
            % only the 4th and beyond need to multiplied with their parent!
            phi(childIdx) = phi(childIdx) * phi(parent(childIdx));
        end
        
        % Save the validity function value to a matrix, if necessary
        if nargout == 2
            % During training not necessary
            validity(k,:) = phi(leafModels);
        end
        if nargout > 2
            % During the training necessary for gradient caculation of the golbal loss function.
            psiAll(k,:) = psi;
            phiAll(k,:) = phi;
        end
        if numberOfOutputs == 1
            % calculation with only ONE output
            outputModel(k,:) = sum(phi(leafModels).*(xRegressor(k,:) * localParameter),2);
        else
            % calculation with several outputs
            temp = cellfun(@(parai) xRegressor(k,:)*parai, parameter_Part,'UniformOutput', false);
            outputModel(k,:) = cellfun(@(tempi) sum(phi(leafModels).*tempi,2), temp);
        end
    end
    
    
    
end

% if any(isinf(outputModel)) || any(isnan(outputModel))
%     warning('sigmoidGlobalModel:simulateParallel', 'INF or NAN value!')
% end

end
