function [data, parameter] = scaleData(obj, data, parameter)
%% SCALEDATA scales the given data between zero and one.
%   Using the LMNTool a scaling of the input data is necessary. During
%   the optimization large values can mislead the optimization steps.
%   Another problem accrues during the optimization: If a nonlinear
%   optimization is initialized in the origin, it is not possible to
%   make any progress. Therefore any data set is scaled between zero
%   and one for each axis.
%
%   [dataScaled, parameter] = scaleData(data, parameter)
%
%   SCALEDATA input:
%       obj         - (object)  Complete model object of the LMNTool
%       parameter   - (struc)   Structure including the scaling parameters.
%
%   SCALDEDATA outputs:
%
%       data        - (N x dim) Scaled data.
%       parameter   - (struc)   Structure including the scaling parameters.
%
%   SYMBOLS AND ABBREVIATIONS
%
%       N:   Number of data samples
%       dim: Number of data dimensions
%
%   LMNtool - Local Model Network Toolbox
%   Torsten Fischer, 13-Mai-2014
%   Institute of Mechanics & Automatic Control, University of Siegen, Germany
%   Copyright (c) 2014 by Prof. Dr.-Ing. Oliver Nelles

% Check given data set for <NaN> and <Inf>
if any(any(isnan(data)))
    warning('There are NaN values in the given data samples!')
elseif any(any(isinf(data)))
    warning('There are INF values in the given data samples!')
end

if isempty(data)
    % If data is empty, give empty matrix back
    data = [];
else
    
    % If no parameters are given, calculate the scaling parameters
    if isempty(parameter)
        parameter.MIN = min(data);
        data = bsxfun(@minus,data,parameter.MIN);
        if any(min(data) == max(data))
            warning('scaleDara:nonUniqueData','All rows of a input coloum are equal')
            dataRange = 1;
        else 
            dataRange = max(data);
        end
        parameter.RANGE = dataRange;
        data = bsxfun(@rdivide,data,parameter.RANGE);
    else % Use the given parameters for scaling
        data = bsxfun(@rdivide,bsxfun(@minus,data,parameter.MIN),parameter.RANGE);
    end
    
end

% Check scaled data set for <NaN> and <Inf>
if any(any(isnan(data)))
    warning('There are NaN values in the transformed data samples!')
elseif any(any(isinf(data)))
    warning('There are INF values in the transformed data samples!')
end
