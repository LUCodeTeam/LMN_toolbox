function [outputModel, validitySimulated] = simulateParallel(obj,xRegressor,zRegressor,localModels,leafModels)
%% SIMULATEPARALLEL  Simulates the output of a local linear neuro-fuzzy model.
%
%   This is needed for dynamic systems, because each time
%   step is depending on its antecessor. The outputs are calculated parallel.
%
%
%       [outputModel,MSFValue,validityFunctionValue] = simulateParallel(obj,xRegressor,zRegressor)
%
%
%   simulateParallel outputs:
%       outputModel - (N x q) Matrix of model outputs.
%       MSFValue    - (N x M) Matrix of (non-normalized) membership
%                             function values.
%       validityFunctionValue - (N x M) Matrix of normalized validity function
%                                       values.
%
%
%   simulateParallel inputs:
%       obj        - (object)    local model object containing all
%                                relevant net and data set information
%                                and variables.
%       xRegressor - (N x nx)    Regression matrix of the consequents (local models).
%       zRegressor - (N x nz)    Regression matrix of the premises (validity functions).
%
%
%   SYMBOLS AND ABBREVIATIONS:
%
%       LM:  Local model
%
%       p:   Number of inputs (physical inputs)
%       q:   Number of outputs
%       N:   Number of data samples
%       M:   Number of LMs
%       nx:  Number of regressors (x)
%       nz:  Number of regressors (z)
%
%
%   LMNtool - Local Model Network Toolbox
%   Tobias Ebert, 18-October-2011
%   Institute of Mechanics & Automatic Control, University of Siegen, Germany
%   Copyright (c) 2012 by Prof. Dr.-Ing. Oliver Nelles


% number of data samples
numberOfSamples = size(xRegressor,1);

% number of outputs
numberOfOutputs = obj.info.numberOfOutputs;

% determine number of regressor inputs
xNumberOfInputRegressorsSum = sum(cellfun(@length,obj.xInputDelay));
zNumberOfInputRegressorsSum = sum(cellfun(@length,obj.zInputDelay));

zUpperBound = localModels(1).zUpperBound;
zLowerBound = localModels(1).zLowerBound;

% initialize the outputs
outputModel = zeros(numberOfSamples,numberOfOutputs);
validitySimulated = ones(numberOfSamples,sum(leafModels));

% save output delays to a variable (the get method in the obj is rather slow)
xOutputDelay = obj.xOutputDelay;
zOutputDelay = obj.zOutputDelay;

% get the parameters of all leaf models
localParameter = [localModels(leafModels).parameter];
if numberOfOutputs > 1
    parameter_Part = [];
    for k = 1:numberOfOutputs
        parameter_Part{k} = localParameter(:,k:numberOfOutputs:end);
    end
end

centers = cell2mat({localModels(leafModels).center}');
standardDeviations = cell2mat({localModels(leafModels).standardDeviation}');

for k = 1:numberOfSamples % through all samples
    
    % if offset is last entry in x-regressor
    %idx = xNumberOfInputRegressorsSum + 1; % for regression matrix x
    
    % if offset is first regressor, the xOutputDelays start at index
    % xNumberOfInputRegressorsSum+2! (delayed inputs + Offset + first idx after that)
    idx = xNumberOfInputRegressorsSum + 2; % for regression matrix x
    
    % fill matrix with output regressors
    for out = 1:numberOfOutputs % through all outputs
        for outReg = 1:length(xOutputDelay{out}) % through all output regressors
            kDelay = k-xOutputDelay{out}(outReg);
            if kDelay > 0
                xRegressor(k,idx) = outputModel(kDelay,out);
            end
            idx = idx + 1;
        end
    end
    
    % as there is no offset in z-reressor, the idx with +1 is corret
    idx = zNumberOfInputRegressorsSum + 1; % for regression matrix z
    
    % fill matrix with output regressors
    for out = 1:numberOfOutputs % through all outputs
        for outReg = 1:length(zOutputDelay{out}) % through all output regressors
            kDelay = k-zOutputDelay{out}(outReg);
            if kDelay > 0
                zRegressor(k,idx) = outputModel(kDelay,out);
            end
            idx = idx + 1;
        end
    end
    
    %     % calculate validity function values, only one row
    %     % MSFValue1row = cellfun(@(cobj) cobj.calculateMSF(zRegressor(k,:)),obj.localModels(obj.leafModels),'UniformOutput',false);
    %     MSFValue1row = arrayfun(@(cobj) cobj.calculateMSF(zRegressor(k,:)),obj.localModels(obj.leafModels),'UniformOutput',false);
    %     validityFunctionValue1row = obj.calculateVFV(MSFValue1row);
    %
    %     % update each leaf model for the calculated sample k
    %     for kk = 1:sum(obj.leafModels)
    %         MSFValue{kk}(end+1,:) = MSFValue1row{kk};
    %         validityFunctionValue{kk}(end+1,1) = validityFunctionValue1row{kk};
    %     end
    %
    %     % calculate model output for sample k
    %     outputModel(k,:) = obj.calcYhat(xRegressor(k,:),validityFunctionValue1row,localParameter);
    
    if length(localModels)==1 % there is only one local=global model
        
        outputModel(k,:) = xRegressor(k,:) * localParameter;
        
    else % for more than one local model
        
        % Check for data outside the premise input space boundaries
        % this prevents influence of reactivatted gaussians
        % Data outside input space boundary (too large)
        outside = zRegressor(k,:) > zUpperBound;
        zRegressor(k,outside) = zUpperBound(outside);
        % Data outside input space boundary (too small)
        outside = zRegressor(k,:) < zLowerBound;
        zRegressor(k,outside) = zLowerBound(outside);
        
        MSFValue1row = sum((bsxfun(@minus,zRegressor(k,:),centers)./standardDeviations).^2,2)';
        MSFValue1row = exp(-MSFValue1row./2);
        validityRow = MSFValue1row./ sum(MSFValue1row);
        
        % save the validity function value to a matrix, if necessary
        if nargout == 2
            validitySimulated(k,:) = validityRow;
        end
        
        if numberOfOutputs == 1
            % calculation with only ONE output
            outputModel(k,:) = sum(validityRow.*(xRegressor(k,:) * localParameter),2);
        else
            % calculation with several outputs
            temp = cellfun(@(parai) xRegressor(k,:)*parai, parameter_Part,'UniformOutput', false);
            outputModel(k,:) = cellfun(@(tempi) sum(validityRow.*tempi,2), temp);
        end
    end
end

end

